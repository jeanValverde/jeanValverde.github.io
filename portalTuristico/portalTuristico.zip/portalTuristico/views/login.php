<!DOCTYPE html>
<html >

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  
  <title>Portal</title>

  <?php include_once '../segmentos/headPublico.php';  ?>
  
  
</head>

<body>

    
    
  <?php include_once '../segmentos/headerPublico.php';  ?>
  
  <main>
     
      
      <!--contenido-->
    
      <?php include_once '../funcionesPublico/login.php'; ?>
      
      
      
      <?php include_once '../segmentos/footerPublico.php'; ?>
      
    
  </main>
  
  <!--footer-->
  
  <?php include_once '../segmentos/footerPublico.php'; ?>

  
  <!--core js-->
  
  
   <?php include_once '../segmentos/footerJs.php'; ?>


   <style>
    #map {
    widh: 50px;
    height: 600px; }
   </style>




</body>

</html>
